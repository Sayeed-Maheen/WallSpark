package com.wallspark.aiwallpapersapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
